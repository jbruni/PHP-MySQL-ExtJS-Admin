<?php

class pmeaAutoload
{
  public $root = '';
  public $suffix = 'pmea';
  public $extension = '.php';
  
  public function __construct( $root = '', $suffix = 'pmea' )
  {
    $this->root = $root;
    spl_autoload_register( array( $this, 'loadClass' ) );
    if ( function_exists( '__autoload' ) )
      spl_autoload_register( '__autoload' );
  }
  
  public function loadClass( $class )
  {
    $ds = DIRECTORY_SEPARATOR;
    
    // The following regex checks for suffix at the beginning AND at least one underscore
    // The preg_split result will be an array, with keys...
    // if match not found, 0 => $class
    // if match is found, 0 => empty, 1 => suffix, 
    // 2 => everything between suffix and last underscore
    // 3 => everything after last underscore
    $parts = preg_split( '/^(' . $this->suffix . ')(.*)_/', $class, null, PREG_SPLIT_DELIM_CAPTURE );
    
    if ( count( $parts ) == 1 )
    {
      $dirname  = $this->root;
      $filename = str_replace( '_', $ds, $parts[0] ) . $this->extension;
    }
    else
    {
      $dirname  = $this_root . $ds . str_replace( '_', $ds, $parts[2] );
      $filename = $this->suffix . $parts[3] . $this->extension;
    }
    
    $filepath = $dirname . $ds . $filename;
    if ( is_file( $filepath ) )
      include( $filepath );
  }
}

?>
